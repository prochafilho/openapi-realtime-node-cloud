import os
import json
import boto3
import requests
import urllib.request

def send_signal_to_cfn(status, reason=""):
    """Send SUCCESS or FAILED signal to CloudFormation"""
    wait_handle_url = os.environ["WAIT_CONDITION_HANDLE"]
    data = json.dumps({
        "Status": status,
        "Reason": reason,
        "UniqueId": "TwilioWebhookSetup",
        "Data": "Twilio webhook setup complete"
    }).encode("utf-8")

    req = urllib.request.Request(wait_handle_url, data=data, method="PUT")
    req.add_header("Content-Type", "application/json")

    try:
        urllib.request.urlopen(req)
        print(f"CloudFormation signal sent: {status}")
    except Exception as e:
        print(f"Failed to send signal: {str(e)}")

def lambda_handler(event, context):
    """Register Twilio Webhook and Signal CloudFormation"""

    try:
        webhook_url = os.environ["WEBHOOK_URL"]
        twilio_sid = os.environ["TWILIO_ACCOUNT_SID"]
        twilio_token = os.environ["TWILIO_AUTH_TOKEN"]
        twilio_number = os.environ["TWILIO_PHONE_NUMBER"]

        response = requests.post(
            f"https://api.twilio.com/2010-04-01/Accounts/{twilio_sid}/IncomingPhoneNumbers.json",
            data={"PhoneNumber": twilio_number, "VoiceUrl": webhook_url, "VoiceMethod": "POST"},
            auth=(twilio_sid, twilio_token)
        )

        response.raise_for_status()
        send_signal_to_cfn("SUCCESS")

    except requests.exceptions.RequestException as e:
        send_signal_to_cfn("FAILED", str(e))
